#!/usr/bin/env python
# -*- coding:utf-8 -*- 
#


from setuptools import setup 

setup(
    name='infoga',

    version='0.1.5',
    description='Email OSINT',
    url='https://github.com/sixtysix-Team',
    
    author = 'BLANK',
    author_email='sixtysixteam0@gmail.com',

    install_requires = ['colorama','requests','urllib3'],
    console =['infoga.py'],
)